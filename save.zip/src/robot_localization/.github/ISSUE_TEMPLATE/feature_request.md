---
name: Feature request
about: FEATURE REQUESTS ARE NOT BEING ACCEPTED
title: ''
labels: ''
assignees: ''

---

# ALL QUESTIONS SHOULD BE DIRECTED TO robotics.stackexchange.com

## When asking a question on robotics.stackexchange.com, please include your full EKF config and one sample message from each sensor input**

# THIS PACKAGE WILL SOON BE DEPRECATED. FEATURE REQUESTS WILL NOT BE ADDRESSED.
