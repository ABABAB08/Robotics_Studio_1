#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <math.h>
#include <vector>

class PoseComparisonNode : public rclcpp::Node {
public:
    PoseComparisonNode()
    : Node("pose_comparison_node"), rmse_amcl_(0.0), rmse_scan_matching_(0.0) {
        // Subscribers for ground truth, AMCL, and scan matching poses
        ground_truth_subscriber_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
            "/ground_truth_pose", 10, std::bind(&PoseComparisonNode::groundTruthCallback, this, std::placeholders::_1));
        amcl_subscriber_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
            "/amcl_pose", 10, std::bind(&PoseComparisonNode::amclCallback, this, std::placeholders::_1));
        scan_matching_subscriber_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
            "/scan_matching_pose", 10, std::bind(&PoseComparisonNode::scanMatchingCallback, this, std::placeholders::_1));

        // Publisher for RMSE information
        rmse_publisher_ = this->create_publisher<geometry_msgs::msg::PoseStamped>("/rmse_pose", 10);

        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(500), std::bind(&PoseComparisonNode::calculateRMSE, this));

        RCLCPP_INFO(this->get_logger(), "Pose comparison node started.");
    }

private:
    // Callback for ground truth poses
    void groundTruthCallback(const geometry_msgs::msg::PoseStamped::SharedPtr msg) {
        RCLCPP_INFO(this->get_logger(), "Received ground truth pose: x=%f, y=%f", msg->pose.position.x, msg->pose.position.y);
        ground_truth_pose_ = *msg;
        ground_truth_positions_.emplace_back(std::make_pair(ground_truth_pose_.pose.position.x, ground_truth_pose_.pose.position.y));
    }

    void amclCallback(const geometry_msgs::msg::PoseStamped::SharedPtr msg) {
        RCLCPP_INFO(this->get_logger(), "Received AMCL pose: x=%f, y=%f", msg->pose.position.x, msg->pose.position.y);
        amcl_pose_ = *msg;
        amcl_positions_.emplace_back(std::make_pair(amcl_pose_.pose.position.x, amcl_pose_.pose.position.y));
    }

    void scanMatchingCallback(const geometry_msgs::msg::PoseStamped::SharedPtr msg) {
        RCLCPP_INFO(this->get_logger(), "Received scan matching pose: x=%f, y=%f", msg->pose.position.x, msg->pose.position.y);
        scan_matching_pose_ = *msg;
        scan_matching_positions_.emplace_back(std::make_pair(scan_matching_pose_.pose.position.x, scan_matching_pose_.pose.position.y));
    }


    // Function to calculate RMSE between ground truth and estimated poses
    void calculateRMSE() {
        if (ground_truth_positions_.size() != amcl_positions_.size() || ground_truth_positions_.size() != scan_matching_positions_.size()) {
            RCLCPP_WARN(this->get_logger(), "Position arrays are not of equal size. Cannot compute RMSE.");
            return;
        }

        size_t count = ground_truth_positions_.size();
        double amcl_error_sum = 0.0;
        double scan_matching_error_sum = 0.0;

        for (size_t i = 0; i < count; ++i) {
            // Calculate squared error for AMCL
            double amcl_error_x = ground_truth_positions_[i].first - amcl_positions_[i].first;
            double amcl_error_y = ground_truth_positions_[i].second - amcl_positions_[i].second;
            amcl_error_sum += amcl_error_x * amcl_error_x + amcl_error_y * amcl_error_y;

            // Calculate squared error for Scan Matching
            double scan_matching_error_x = ground_truth_positions_[i].first - scan_matching_positions_[i].first;
            double scan_matching_error_y = ground_truth_positions_[i].second - scan_matching_positions_[i].second;
            scan_matching_error_sum += scan_matching_error_x * scan_matching_error_x + scan_matching_error_y * scan_matching_error_y;
        }

        // Compute RMSE for AMCL and Scan Matching
        rmse_amcl_ = sqrt(amcl_error_sum / count);
        rmse_scan_matching_ = sqrt(scan_matching_error_sum / count);

        RCLCPP_INFO(this->get_logger(), "RMSE (AMCL): %f, RMSE (Scan Matching): %f", rmse_amcl_, rmse_scan_matching_);
    }

    // Subscribers
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr ground_truth_subscriber_;
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr amcl_subscriber_;
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr scan_matching_subscriber_;

    // Publisher for RMSE (if needed)
    rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr rmse_publisher_;

    // Timer for periodic RMSE calculation
    rclcpp::TimerBase::SharedPtr timer_;

    // Pose data
    geometry_msgs::msg::PoseStamped ground_truth_pose_;
    geometry_msgs::msg::PoseStamped amcl_pose_;
    geometry_msgs::msg::PoseStamped scan_matching_pose_;

    // RMSE variables
    double rmse_amcl_;
    double rmse_scan_matching_;

    // Position arrays to calculate RMSE
    std::vector<std::pair<double, double>> ground_truth_positions_;
    std::vector<std::pair<double, double>> amcl_positions_;
    std::vector<std::pair<double, double>> scan_matching_positions_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PoseComparisonNode>());
    rclcpp::shutdown();
    return 0;
}
