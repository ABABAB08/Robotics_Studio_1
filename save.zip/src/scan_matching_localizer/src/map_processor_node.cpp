#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/imgcodecs.hpp>
#include <iostream>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/transform_datatypes.h>  // Required for Matrix3x3 and Quaternion

class MapProcessorNode : public rclcpp::Node {
public:
    MapProcessorNode()
    : Node("map_processor_node"), robot_x(0), robot_y(0), robot_theta(0) {
        subscription_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
            "/map", 10, std::bind(&MapProcessorNode::mapCallback, this, std::placeholders::_1));
        scan_subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
            "/scan", 10, std::bind(&MapProcessorNode::scanCallback, this, std::placeholders::_1));
        odom_subscriber_ = this->create_subscription<nav_msgs::msg::Odometry>(
            "/odom", 10, std::bind(&MapProcessorNode::odomCallback, this, std::placeholders::_1));

        // Create four windows for debugging
        cv::namedWindow("Edge Image", cv::WINDOW_AUTOSIZE);
        cv::namedWindow("Scan", cv::WINDOW_AUTOSIZE);
        cv::namedWindow("Map Section Image", cv::WINDOW_AUTOSIZE);
        cv::namedWindow("Matches", cv::WINDOW_AUTOSIZE);
    }

private:
    // Callback for processing laser scans
    void scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg) {
        laser_scan_image_ = ConvertLaserScanToImage(msg);
        cv::imshow("Scan", laser_scan_image_);
        cv::waitKey(1);

        // Debugging: Display information about scan
        std::cout << "Laser scan size: " << msg->ranges.size() << std::endl;

        // After receiving laser scan data, compare with map if available
        if (!map_edges_.empty()) {
            compareImages(map_edges_, laser_scan_image_);
        }
    }

    // Callback for processing occupancy grid maps
    void mapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr mapMsg) {
        occupancyGridToImage(mapMsg);

        // Extract a section of the map around the robot
        cv::Mat map_section = ExtractMapSection(m_MapColImage, robot_x, robot_y, map_scale_);
        std::cout << "Extracting map section at robot position: (" << robot_x << ", " << robot_y << ")" << std::endl;

        // Perform edge detection on the updated map section (Image B)
        map_edges_ = PerformEdgeDetection(map_section);

        // Display the map section and edges in the windows
        cv::imshow("Map Section Image", map_section);
        cv::imshow("Edge Image", map_edges_);
        cv::waitKey(1);

        // Debugging: Display size of edge image and map section
        std::cout << "Map section size: " << map_section.size() << ", Edge image size: " << map_edges_.size() << std::endl;

        // Compare Image B (map edges) with Image C (laser scan) if available
        if (!laser_scan_image_.empty()) {
            compareImages(map_edges_, laser_scan_image_);
        }
    }

    // Callback for getting robot's pose through odometry
    void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg) {
        tf2::Quaternion q(
            msg->pose.pose.orientation.x,
            msg->pose.pose.orientation.y,
            msg->pose.pose.orientation.z,
            msg->pose.pose.orientation.w
        );
        
        // Compute yaw directly from quaternion
        robot_theta = getYawFromQuaternion(q);  
        robot_x = msg->pose.pose.position.x;
        robot_y = msg->pose.pose.position.y;

        // Debugging: Print robot's pose
        std::cout << "Robot position: (" << robot_x << ", " << robot_y << "), theta: " << robot_theta << std::endl;
    }

    // Function to extract yaw from quaternion
    double getYawFromQuaternion(const tf2::Quaternion &q) {
        double roll, pitch, yaw;
        tf2::Matrix3x3 m(q);
        m.getRPY(roll, pitch, yaw);  // Extract roll, pitch, and yaw from the quaternion
        return yaw;
    }

    // Helper function to extract a section of the map (Image A)
    cv::Mat ExtractMapSection(const cv::Mat& fullMap, double robot_x, double robot_y, double map_resolution, int window_size = 400) {
        int x_center = static_cast<int>((robot_x - origin_x) / map_resolution);
        int y_center = static_cast<int>((robot_y - origin_y) / map_resolution);

        // Ensure the extracted region doesn't go out of bounds
        int x_start = std::max(0, x_center - window_size / 2);
        int y_start = std::max(0, y_center - window_size / 2);
        int x_end = std::min(fullMap.cols, x_center + window_size / 2);
        int y_end = std::min(fullMap.rows, y_center + window_size / 2);

        cv::Rect roi(x_start, y_start, x_end - x_start, y_end - y_start);
        return fullMap(roi).clone(); // Clone to get a copy of the section
    }

    // Edge Detection using Canny (Image B)
    cv::Mat PerformEdgeDetection(const cv::Mat& map_section) {
        cv::Mat edges;
        // Debugging: Print parameters for edge detection
        std::cout << "Performing edge detection with thresholds 50 and 150" << std::endl;
        cv::Canny(map_section, edges, 45, 200); // Adjust thresholds as necessary
        return edges;
    }

    // Convert Laser Scan to Image (Image C)
    cv::Mat ConvertLaserScanToImage(const sensor_msgs::msg::LaserScan::SharedPtr& scan, int image_size = 400, float scale = 30.0f) {
        cv::Mat scan_image = cv::Mat::zeros(image_size, image_size, CV_8UC1);
        float angle = scan->angle_min;

        for (size_t i = 0; i < scan->ranges.size(); ++i) {
            float range = scan->ranges[i];
            if (range > scan->range_min && range < scan->range_max) {
                int x = static_cast<int>(image_size / 2 + (range * cos(angle) * scale));
                int y = static_cast<int>(image_size / 2 + (range * sin(angle) * scale));
                
                if (x >= 0 && x < image_size && y >= 0 && y < image_size) {
                    scan_image.at<uchar>(y, x) = 255;  // Mark the scan point
                }
            }
            angle += scan->angle_increment;
        }
        return scan_image;
    }

    // Function to convert Occupancy Grid to Image
    void occupancyGridToImage(const nav_msgs::msg::OccupancyGrid::SharedPtr grid) {
        int grid_data;
        unsigned int row, col, val;

        m_temp_img = cv::Mat::zeros(grid->info.height, grid->info.width, CV_8UC1);

        for (row = 0; row < grid->info.height; row++) {
            for (col = 0; col < grid->info.width; col++) {
                grid_data = grid->data[row * grid->info.width + col];
                if (grid_data != -1) {
                    val = 255 - (255 * grid_data) / 100;
                    val = (val == 0) ? 255 : 0;
                    m_temp_img.at<uchar>(grid->info.height - row - 1, col) = val;
                } else {
                    m_temp_img.at<uchar>(grid->info.height - row - 1, col) = 0;
                }
            }
        }

        map_scale_ = grid->info.resolution;
        origin_x = grid->info.origin.position.x;
        origin_y = grid->info.origin.position.y;

        cv::Mat kernel = (cv::Mat_<uchar>(3, 3) << 0, 0, 0, 0, 1, 0, 0, 0, 0);
        cv::erode(m_temp_img, m_MapBinImage, kernel);

        m_MapColImage.create(m_MapBinImage.size(), CV_8UC3);
        cv::cvtColor(m_MapBinImage, m_MapColImage, cv::COLOR_GRAY2BGR);
    }

    // Compare Image B (edges of map) and Image C (laser scan)
    void compareImages(const cv::Mat& map_edges, const cv::Mat& laser_scan) {
        std::vector<cv::Point2f> srcPoints, dstPoints;
        detectAndMatchFeatures(map_edges, laser_scan, srcPoints, dstPoints);

        if (srcPoints.size() >= 5 && dstPoints.size() >= 5) {
            cv::Mat transform_matrix = cv::estimateAffinePartial2D(srcPoints, dstPoints);
            if (!transform_matrix.empty()) {
                double angle_difference = atan2(transform_matrix.at<double>(1, 0), transform_matrix.at<double>(0, 0));
                angle_difference = angle_difference * 180.0 / CV_PI;
                std::cout << "Estimated yaw angle change: " << angle_difference << " degrees" << std::endl;
            } else {
                std::cout << "Failed to estimate transformation matrix." << std::endl;
            }

            // Display matches in a new window
            cv::Mat matches_img;
            cv::drawMatches(map_edges, std::vector<cv::KeyPoint>(), laser_scan, std::vector<cv::KeyPoint>(), std::vector<cv::DMatch>(), matches_img);
            cv::imshow("Matches", matches_img);
            cv::waitKey(1);
        } else {
            std::cout << "Not enough points for yaw estimation. SrcPoints: " << srcPoints.size() << " DstPoints: " << dstPoints.size() << std::endl;
        }
    }

    void detectAndMatchFeatures(const cv::Mat& img1, const cv::Mat& img2, std::vector<cv::Point2f>& srcPoints, std::vector<cv::Point2f>& dstPoints) {
        cv::Ptr<cv::ORB> orb = cv::ORB::create(1000);  // Adjust number of features for ORB
        std::vector<cv::KeyPoint> keypoints1, keypoints2;
        cv::Mat descriptors1, descriptors2;

        // Detect features and compute descriptors
        orb->detectAndCompute(img1, cv::noArray(), keypoints1, descriptors1);
        orb->detectAndCompute(img2, cv::noArray(), keypoints2, descriptors2);

        std::cout << "Detected " << keypoints1.size() << " features in map edges (Image B)." << std::endl;
        std::cout << "Detected " << keypoints2.size() << " features in laser scan (Image C)." << std::endl;

        // Match descriptors using BFMatcher and Lowe's ratio test
        cv::BFMatcher matcher(cv::NORM_HAMMING);
        std::vector<cv::DMatch> matches;
        matcher.match(descriptors1, descriptors2, matches);

        std::vector<cv::DMatch> good_matches;
        for (size_t i = 0; i < matches.size() - 1; i++) {
            if (matches[i].distance < 0.50 * matches[i + 1].distance) {
                good_matches.push_back(matches[i]);
            }
        }

        std::cout << "Found " << matches.size() << " matches. Good matches: " << good_matches.size() << std::endl;

        // Extract matched points
        for (const auto& match : good_matches) {
            srcPoints.push_back(keypoints1[match.queryIdx].pt);
            dstPoints.push_back(keypoints2[match.trainIdx].pt);
        }

        std::cout << "Using " << srcPoints.size() << " matched points for yaw estimation." << std::endl;

        // Debugging: Print the matched keypoint locations
        for (size_t i = 0; i < srcPoints.size(); ++i) {
            std::cout << "Map: (" << srcPoints[i].x << ", " << srcPoints[i].y << ") -> Laser: ("
                    << dstPoints[i].x << ", " << dstPoints[i].y << ")" << std::endl;
        }

        // Visualize matches
        cv::Mat matches_img;
        cv::drawMatches(img1, keypoints1, img2, keypoints2, good_matches, matches_img);
        cv::imshow("Matches", matches_img);
        cv::waitKey(1);


    }


    // Subscriptions
    rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr subscription_;
    rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_subscriber_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_subscriber_;

    // Internal state
    double robot_x, robot_y, robot_theta;
    cv::Mat m_temp_img;
    cv::Mat m_MapBinImage;
    cv::Mat m_MapColImage;
    cv::Mat map_edges_;
    cv::Mat laser_scan_image_;
    double map_scale_;
    double origin_x;
    double origin_y;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<MapProcessorNode>());
    rclcpp::shutdown();
    return 0;
}