from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # Start the scan_matching_node (your custom node)
        Node(
            package='scan_matching_localizer',
            executable='scan_matching_localizer.exe',  # Update with the correct name
            name='scan_matching_localizer',
            output='screen'
        )
    ])

